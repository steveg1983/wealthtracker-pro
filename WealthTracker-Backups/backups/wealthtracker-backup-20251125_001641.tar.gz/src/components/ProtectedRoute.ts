export { default, ProtectedRoute, type ProtectedRouteProps } from './auth/ProtectedRoute';
export { default as withProtectedRoute } from '../hoc/withProtectedRoute';
