import { RealTimePriceService } from './realtimePriceService';

export const realTimePriceService = new RealTimePriceService();

export type { PriceUpdate } from './realtimePriceService';
