export default function TestPage() {
  return (
    <div>
      <h1>Test Page Works!</h1>
      <p>This is a simple test page to verify routing is working.</p>
      <p>If you can see this, the basic page rendering is functional.</p>
    </div>
  );
}