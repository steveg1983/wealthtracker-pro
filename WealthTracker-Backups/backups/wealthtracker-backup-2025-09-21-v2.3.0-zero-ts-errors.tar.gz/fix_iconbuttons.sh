#!/bin/bash

# Fix IconButton patterns across the codebase
# Pattern: icon={<IconName size={N} />} becomes icon={IconName} and size={N}

echo "Fixing IconButton patterns..."

# Get all files with IconButton icon={< patterns
files=$(grep -r "icon={<.*size=" src/ | cut -d: -f1 | sort | uniq)

for file in $files; do
    echo "Processing $file..."

    # Use sed to fix the patterns
    # This is complex, so let's use a more controlled approach with individual replacements

    # First, let's see what patterns exist in this file
    grep "icon={<.*size=" "$file" || continue
done

echo "Done fixing IconButton patterns"