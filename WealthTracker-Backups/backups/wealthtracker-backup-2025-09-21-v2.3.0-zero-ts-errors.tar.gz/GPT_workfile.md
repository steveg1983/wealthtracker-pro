# GPT Workfile

## Overview
Ongoing cleanup of dashboard widgets to eliminate ESLint warnings (unused imports, missing hook dependencies, loose `any` types) after earlier refactors to account selection, analytics, and planning widgets.

## Current Status
- Account selector, add account modal, allocation analysis, business/collaboration widgets, data intelligence, budget vs actual, AI analytics, financial planning, and sync status widgets are now strongly typed with memoised loaders and no stray `any`s.
- `npx eslint src/components/widgets` now reports **20 warnings** clustered in the remaining widget modules listed below.

## In-Progress Focus
Continue iterating through widgets to remove lint noise. Next target: `BankConnectionsWidget.tsx`, followed by the other flagged files.

## Detailed Next Steps
1. **BankConnectionsWidget.tsx**
   - Type the payload returned by `bankConnectionService` (replace `any`).
   - Either leverage the `settings` prop and `connectedCount` or remove the unused assignments.
   - Ensure hooks (if any) have stable dependencies; rerun `npx eslint src/components/widgets/BankConnectionsWidget.tsx`.
2. **BillReminderWidget.tsx**
   - Replace helper return types declared as `any` with concrete interfaces.
   - Remove the unused `description` parameter, or use it where appropriate.
3. **BudgetSummaryWidget.tsx**
   - Drop unused `PiggyBankIcon`; wire `startDate`/`endDate` into calculations or delete.
   - Replace `any` on aggregated budget data with typed structures.
4. **InvestmentEnhancementWidget.tsx**
   - Remove empty prop interface, wrap metric calculations in `useCallback`, include dependencies in `useEffect`.
5. **SecurityWidget.tsx & TaxPlanningWidget.tsx**
   - Similar treatment: tighten prop typing, memoise calculations, address unused setters/icons.
6. **WidgetRenderer.tsx**
   - Remove unused `useEffect`/`logger` imports or implement their behaviour.
7. **PerformanceWidget.cy.tsx**
   - Rename or utilise the unused `initialTime` argument in the Cypress helper.

After each widget update:
- Run `npx eslint path/to/widget.tsx`.
- Once a batch is complete, rerun `npx eslint src/components/widgets` to confirm progress.

## How to Continue
- Work through the list above sequentially (BankConnectionsWidget → BillReminderWidget → BudgetSummaryWidget → …).
- Maintain the established pattern: replace `any`, stabilise hooks with `useCallback`/`useMemo`, remove unused imports/props, and ensure UI references the cleaned state.
- Keep commits batched logically per widget or small group.

## Useful Commands
- `npx eslint src/components/widgets/BankConnectionsWidget.tsx`
- `npx eslint src/components/widgets/BillReminderWidget.tsx`
- `npx eslint src/components/widgets`
- `git status -sb`

## References
Latest full lint scan output (20 warnings) captured via `npx eslint src/components/widgets` immediately before this workfile update.
