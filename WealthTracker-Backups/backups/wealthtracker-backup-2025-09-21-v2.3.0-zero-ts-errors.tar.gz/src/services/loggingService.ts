/**
 * Professional Logging Service
 *
 * Provides centralized logging with different levels and environments.
 * In production, logs are suppressed except for errors.
 * In development, all logs are shown with proper formatting.
 *
 * This follows the principle: "Professional-grade, zero compromises"
 */

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  level: LogLevel;
  message: string;
  data?: unknown;
  timestamp: Date;
  source?: string;
}

class LoggingService {
  private isDevelopment = import.meta.env.DEV;
  private isTest = import.meta.env.MODE === 'test';
  private logHistory: LogEntry[] = [];
  private maxHistorySize = 100;

  /**
   * Log debug information (development only)
   */
  debug(message: string, data?: unknown, source?: string): void {
    if (this.isDevelopment && !this.isTest) {
      this.log('debug', message, data, source);
    }
  }

  /**
   * Log general information (development only)
   */
  info(message: string, data?: unknown, source?: string): void {
    if (this.isDevelopment && !this.isTest) {
      this.log('info', message, data, source);
    }
  }

  /**
   * Log warnings (development and production)
   */
  warn(message: string, data?: unknown, source?: string): void {
    this.log('warn', message, data, source);
  }

  /**
   * Log errors (always logged)
   */
  error(message: string, error?: unknown, source?: string): void {
    this.log('error', message, error, source);
  }

  /**
   * Internal logging method
   */
  private log(level: LogLevel, message: string, data?: unknown, source?: string): void {
    const entry: LogEntry = {
      level,
      message,
      data,
      timestamp: new Date(),
      source
    };

    // Add to history
    this.logHistory.unshift(entry);
    if (this.logHistory.length > this.maxHistorySize) {
      this.logHistory.pop();
    }

    // Console output (respecting environment)
    if (this.shouldLog(level)) {
      const timestamp = entry.timestamp.toISOString();
      const prefix = source ? `[${source}]` : '';
      const logMessage = `${timestamp} ${prefix} ${message}`;

      switch (level) {
        case 'debug':
          console.debug(logMessage, data);
          break;
        case 'info':
          console.info(logMessage, data);
          break;
        case 'warn':
          console.warn(logMessage, data);
          break;
        case 'error':
          console.error(logMessage, data);
          break;
      }
    }
  }

  private shouldLog(level: LogLevel): boolean {
    if (this.isTest) return false;
    if (level === 'error') return true;
    if (level === 'warn') return true;
    return this.isDevelopment;
  }

  /**
   * Get recent log entries
   */
  getHistory(count = 50): LogEntry[] {
    return this.logHistory.slice(0, count);
  }

  /**
   * Clear log history
   */
  clearHistory(): void {
    this.logHistory = [];
  }
}

export const logger = new LoggingService();