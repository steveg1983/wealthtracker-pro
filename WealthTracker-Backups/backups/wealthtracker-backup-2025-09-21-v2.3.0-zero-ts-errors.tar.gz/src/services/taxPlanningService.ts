import Decimal from 'decimal.js';

type DecimalType = Decimal;

export interface TaxEstimate {
  grossIncome: DecimalType;
  taxableIncome: DecimalType;
  federalTax: DecimalType;
  stateTax: DecimalType;
  socialSecurityTax: DecimalType;
  medicareTax: DecimalType;
  totalTax: DecimalType;
  effectiveRate: number;
  marginalRate: number;
}

export interface TaxDeduction {
  name: string;
  amount: DecimalType;
  category: 'above-the-line' | 'itemized' | 'standard';
}

export const taxPlanningService = {
  calculateTaxEstimate(income: DecimalType, deductions: TaxDeduction[] = []): TaxEstimate {
    // Simplified tax calculation - replace with actual tax brackets
    const standardDeduction = new Decimal(13850); // 2023 single filer
    const totalDeductions = deductions.reduce(
      (sum, d) => sum.plus(d.amount),
      standardDeduction
    );

    const taxableIncome = Decimal.max(0, income.minus(totalDeductions));
    const federalTax = taxableIncome.times(0.22); // Simplified
    const stateTax = taxableIncome.times(0.05); // Simplified
    const socialSecurityTax = Decimal.min(income, 160200).times(0.062);
    const medicareTax = income.times(0.0145);
    const totalTax = federalTax.plus(stateTax).plus(socialSecurityTax).plus(medicareTax);

    return {
      grossIncome: income,
      taxableIncome,
      federalTax,
      stateTax,
      socialSecurityTax,
      medicareTax,
      totalTax,
      effectiveRate: income.isZero() ? 0 : totalTax.dividedBy(income).times(100).toNumber(),
      marginalRate: 22
    };
  },

  getDeductionCategories(): string[] {
    return ['above-the-line', 'itemized', 'standard'];
  },

  estimateQuarterlyPayments(annualTax: DecimalType): DecimalType[] {
    const quarterlyAmount = annualTax.dividedBy(4);
    return [quarterlyAmount, quarterlyAmount, quarterlyAmount, quarterlyAmount];
  }
};