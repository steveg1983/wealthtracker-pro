import Decimal from 'decimal.js';
import { Budget, Transaction } from '../types';

type DecimalType = Decimal;

export interface BudgetComparison {
  budgetId: string;
  currentSpent: DecimalType;
  previousSpent: DecimalType;
  percentageChange: DecimalType;
  trending: 'up' | 'down' | 'stable';
}

export interface BudgetMetrics {
  totalBudget: DecimalType;
  totalSpent: DecimalType;
  percentageUsed: DecimalType;
  remainingAmount: DecimalType;
  daysInPeriod: number;
  averageDailySpend: DecimalType;
  projectedMonthEnd: DecimalType;
}

export const budgetComparisonService = {
  calculateBudgetComparison(
    budget: Budget,
    currentTransactions: Transaction[],
    previousTransactions: Transaction[]
  ): BudgetComparison {
    const currentSpent: DecimalType = currentTransactions
      .filter(t => t.category === budget.categoryId)
      .reduce((sum, t) => sum.plus(Math.abs(t.amount)), new Decimal(0));

    const previousSpent: DecimalType = previousTransactions
      .filter(t => t.category === budget.categoryId)
      .reduce((sum, t) => sum.plus(Math.abs(t.amount)), new Decimal(0));

    const percentageChange = previousSpent.isZero()
      ? new Decimal(0)
      : currentSpent.minus(previousSpent).dividedBy(previousSpent).times(100);

    let trending: 'up' | 'down' | 'stable' = 'stable';
    if (percentageChange.greaterThan(5)) {
      trending = 'up';
    } else if (percentageChange.lessThan(-5)) {
      trending = 'down';
    }

    return {
      budgetId: budget.id,
      currentSpent,
      previousSpent,
      percentageChange,
      trending
    };
  },

  calculateMetrics(
    budget: Budget,
    transactions: Transaction[],
    startDate: Date,
    endDate: Date
  ): BudgetMetrics {
    const totalBudget = new Decimal(budget.amount);

    const totalSpent = transactions
      .filter(t => t.category === budget.categoryId)
      .filter(t => {
        const transDate = new Date(t.date);
        return transDate >= startDate && transDate <= endDate;
      })
      .reduce((sum, t) => sum.plus(Math.abs(t.amount)), new Decimal(0));

    const percentageUsed = totalBudget.isZero()
      ? new Decimal(0)
      : totalSpent.dividedBy(totalBudget).times(100);

    const remainingAmount = totalBudget.minus(totalSpent);

    const daysInPeriod = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const daysElapsed = Math.ceil((new Date().getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));

    const averageDailySpend = daysElapsed > 0
      ? totalSpent.dividedBy(daysElapsed)
      : new Decimal(0);

    const projectedMonthEnd = averageDailySpend.times(daysInPeriod);

    return {
      totalBudget,
      totalSpent,
      percentageUsed,
      remainingAmount,
      daysInPeriod,
      averageDailySpend,
      projectedMonthEnd
    };
  }
};