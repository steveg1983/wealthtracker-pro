/**
 * Performance Monitoring Service
 * Tracks Core Web Vitals, custom metrics, and provides performance insights
 */

import { logger } from './loggingService';

interface PerformanceMetric {
  name: string;
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  timestamp: number;
}

interface PerformanceReport {
  metrics: PerformanceMetric[];
  timestamp: number;
  url: string;
  userAgent: string;
}

class PerformanceService {
  private metrics: PerformanceMetric[] = [];
  private observer: PerformanceObserver | null = null;
  private reportCallback: ((report: PerformanceReport) => void) | null = null;
  private isInitialized = false;

  // Core Web Vitals thresholds
  private readonly thresholds = {
    LCP: { good: 2500, poor: 4000 }, // Largest Contentful Paint (ms)
    FID: { good: 100, poor: 300 },   // First Input Delay (ms)
    CLS: { good: 0.1, poor: 0.25 },  // Cumulative Layout Shift
    TTFB: { good: 800, poor: 1800 }, // Time to First Byte (ms)
    INP: { good: 200, poor: 500 }    // Interaction to Next Paint (ms)
  };

  /**
   * Initialize performance monitoring
   */
  initialize(callback?: (report: PerformanceReport) => void): void {
    if (this.isInitialized || typeof window === 'undefined') return;

    this.reportCallback = callback || null;
    this.setupWebVitalsObserver();
    this.isInitialized = true;

    logger.info('Performance monitoring initialized');
  }

  /**
   * Setup Web Vitals observer
   */
  private setupWebVitalsObserver(): void {
    if (typeof PerformanceObserver === 'undefined') return;

    try {
      // Observe paint timing
      const paintObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.name === 'first-contentful-paint') {
            this.recordMetric('FCP', entry.startTime);
          }
        }
      });
      paintObserver.observe({ entryTypes: ['paint'] });

      // Observe LCP
      const lcpObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        if (entries.length > 0) {
          const lastEntry = entries[entries.length - 1] as PerformanceEntry & { renderTime?: number; loadTime?: number };
          const lcp = lastEntry.renderTime || lastEntry.loadTime || lastEntry.startTime;
          this.recordMetric('LCP', lcp);
        }
      });
      lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });

    } catch (error) {
      logger.warn('Failed to setup performance observers:', error);
    }
  }

  /**
   * Record a performance metric
   */
  recordMetric(name: string, value: number): void {
    const rating = this.getRating(name, value);

    const metric: PerformanceMetric = {
      name,
      value,
      rating,
      timestamp: Date.now()
    };

    this.metrics.push(metric);

    // Keep only recent metrics
    if (this.metrics.length > 100) {
      this.metrics = this.metrics.slice(-50);
    }

    logger.debug(`Performance metric: ${name} = ${value}ms (${rating})`);
  }

  /**
   * Get performance rating based on thresholds
   */
  private getRating(metric: string, value: number): 'good' | 'needs-improvement' | 'poor' {
    const threshold = this.thresholds[metric as keyof typeof this.thresholds];
    if (!threshold) return 'good';

    if (value <= threshold.good) return 'good';
    if (value <= threshold.poor) return 'needs-improvement';
    return 'poor';
  }

  /**
   * Get current performance report
   */
  getReport(): PerformanceReport {
    return {
      metrics: [...this.metrics],
      timestamp: Date.now(),
      url: window.location.href,
      userAgent: navigator.userAgent
    };
  }

  /**
   * Clear all metrics
   */
  clearMetrics(): void {
    this.metrics = [];
  }

  /**
   * Measure function execution time
   */
  measureFunction<T>(name: string, fn: () => T): T {
    const start = performance.now();
    const result = fn();
    const duration = performance.now() - start;

    this.recordMetric(`function-${name}`, duration);
    return result;
  }

  /**
   * Measure async function execution time
   */
  async measureAsyncFunction<T>(name: string, fn: () => Promise<T>): Promise<T> {
    const start = performance.now();
    const result = await fn();
    const duration = performance.now() - start;

    this.recordMetric(`async-${name}`, duration);
    return result;
  }
}

export const performanceService = new PerformanceService();
export default performanceService;