export interface OCRResult {
  text: string;
  confidence: number;
  blocks: OCRBlock[];
  metadata: {
    language: string;
    orientation: number;
    script: string;
  };
}

export interface OCRBlock {
  text: string;
  confidence: number;
  boundingBox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  words: OCRWord[];
}

export interface OCRWord {
  text: string;
  confidence: number;
  boundingBox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export async function performOCR(imageData: Blob | File): Promise<OCRResult> {
  return ocrService.processImage(imageData);
}

export const ocrService = {
  async processImage(imageData: Blob | File): Promise<OCRResult> {
    // Placeholder implementation - would integrate with OCR API
    return {
      text: '',
      confidence: 0,
      blocks: [],
      metadata: {
        language: 'en',
        orientation: 0,
        script: 'Latin'
      }
    };
  },

  async extractReceiptData(imageData: Blob | File): Promise<any> {
    const ocrResult = await this.processImage(imageData);
    // Parse receipt-specific data from OCR result
    return {
      merchant: '',
      date: null,
      total: 0,
      items: []
    };
  },

  async extractDocumentData(imageData: Blob | File): Promise<any> {
    const ocrResult = await this.processImage(imageData);
    // Parse document-specific data from OCR result
    return {
      type: 'unknown',
      content: ocrResult.text,
      metadata: ocrResult.metadata
    };
  }
};